<?php
include("header.php");
session_destroy();
header("Location: logins.php");




?>