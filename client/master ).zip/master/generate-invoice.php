<?php 
  include('dashboard-header.php'); 


?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
 
  <h1 class="h1">Dashboard</h1>
  

  <form action="" method="post"> 
  <div class="form-group">
    <label for="exampleInputEmail1">Annual Service</label>
    <input type="number" name="annual_service" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Mini Valet</label>
    <input type="number" name="mini_valet" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Car mat</label>
    <input type="number" name="car_mat" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
  </div>

  <button name="price" type="submit" class="btn btn-primary">Submit</button>
</form>
<?php
  if(isset($_POST['price'])){
    $id = $_GET['id'];
    $query_vehicle = "SELECT * FROM `booking` WHERE id='$id'";
    $result_vehicles = mysqli_query($conn, $query_vehicle);
    $row = mysqli_fetch_assoc($result_vehicles);
    $name =  $row['user'];
    $vehicle = $row['vehicle'];
    $phone = $row['phone'];
    $licence = $row['licence'];
    
  $annual_service = $_POST['annual_service'];
  $mini_valet = $_POST['mini_valet'];
  $car_mat = $_POST['car_mat'];
  $total = $annual_service + $mini_valet + $car_mat;

  mysqli_query($conn, "UPDATE invoice SET name='$name', mobile='$phone', licence='$licence', vehicle='$vehicle',annual_service='$annual_service', mini_valet='$mini_valet', car_mat='$car_mat', total='$total'");
}
?>
<a class="btn btn-success" href="invoice.php"> Generate Invoice</a>
</main>
<?php include ('dashboard-footer.php') ?>