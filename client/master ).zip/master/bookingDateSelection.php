<?php

//date("Y-m-d"); //2020-01-25 



//$query = "SELECT COUNT(*) AS countNumb FROM booking WHERE date_in = "+$date;
echo "Select a date";
echo "@Full booked day";
$i = 0;
while ($i < 5){
    echo "@2020-01-25";
    $i++;
}
?>