<?php
// if (session_status() == PHP_SESSION_ACTIVE) {
    
//   }else{
//       session_start();
      
//   }
//session_start();

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "garage";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$databasename);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>